function clear() {
  for (a in person) {
    document.getElementById(a).value = '';
  }
}
