let Ap = ()=>{
    return(
        <div>
            <a href="https://ipr.ap.nic.in/">
  
            </a>

        </div>
    )
}
export default Ap;